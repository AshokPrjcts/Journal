[Your Name]
[Department], [Institution]
[Address, Country]
[email@institution.edu]

[Date]

To the Editor-in-Chief
Knowledge-Based Systems (Elsevier)

Dear Editor-in-Chief,

Please find enclosed our short communication entitled "Knowledge-Based Machine
Learning for Data-Driven Decision Intelligence in Digital Transformation and
Entrepreneurship" for consideration in Knowledge-Based Systems.

The manuscript falls squarely within the journal's scope of knowledge-based and
artificial-intelligence techniques that support human prediction and
decision-making through data science. We propose KG-DI (Knowledge-Guided
Decision Intelligence), a framework that embeds theory-grounded managerial
knowledge as a prior inside a stochastic gradient-boosting learner and couples
it with a cost-sensitive decision layer. KG-DI predicts firm-level
digital-transformation readiness and converts those predictions into
cost-aware managerial decisions.

The contribution is threefold: (i) a knowledge prior that injects domain
knowledge directly into the learner while preserving interpretability; (ii) a
decision-intelligence layer that minimizes expected managerial misclassification
cost; and (iii) a fully reproducible benchmark with four baselines, a 2x2
factorial ablation, paired significance testing, and a sensitivity analysis.
Over 24 matched holdout splits, KG-DI attains the highest AUC and significantly
outperforms logistic regression, random forest, and decision-tree baselines,
with the knowledge prior contributing a statistically significant gain. All
code, data, figures, and tables are openly available and reproduce every
reported result with a single command.

We confirm that this work is original, has not been published previously, and is
not under consideration elsewhere. The authors declare no competing interests.
We believe the paper will interest the Knowledge-Based Systems readership working
at the intersection of knowledge-based systems, machine learning, and
decision support for business.

Thank you for your consideration.

Sincerely,
[Your Name] (on behalf of all authors)
