# Declarations

## CRediT author statement
**[Full Name]:** Conceptualization, Methodology, Software, Formal analysis,
Validation, Visualization, Writing – original draft, Writing – review and
editing.

## Declaration of competing interests
The author declares no competing financial or personal interests.

## Funding
This research did not receive any specific grant from funding agencies in the
public, commercial, or not-for-profit sectors.

## Data and code availability
All data are programmatically generated and all code, models, figures, and
tables are openly available at:
https://github.com/AshokPrjcts/Journal (directory `kbml-decision-intelligence`).
A single command (`python3 src/experiment.py`) reproduces every reported
artifact. For an empirical study, the synthetic generator can be replaced by a
real dataset deposited in a public repository (e.g., Zenodo or Mendeley Data)
and cited accordingly, per the journal's research-data policy (Option C).

## Declaration of generative AI and AI-assisted technologies in the manuscript preparation process
During the preparation of this work the author used an AI assistant to help
scaffold the reproducible codebase and draft structure. After using this tool,
the author reviewed and edited the content as needed and takes full
responsibility for the content of the published article. No generative AI was
used to create or alter any figure; all figures are rendered programmatically
from experimental output.
