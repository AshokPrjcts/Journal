# Title Page

## Article title
Knowledge-Based Machine Learning for Data-Driven Decision Intelligence in
Digital Transformation and Entrepreneurship

## Article type
Short Communication

## Authors and affiliations
[Full Name]<sup>a</sup>

<sup>a</sup> [Department], [Institution], [Full Postal Address, City, Postal
Code, Country]

## Corresponding author
[Full Name]
[Department], [Institution]
[Full Postal Address, Country]
Email: [email@institution.edu]

## Present/permanent address (if applicable)
[Only if an author has changed affiliation since the work was carried out.]

---

*Note: Author identifying information is confined to this title page. The main
manuscript file (03_manuscript.md) is anonymized to support the journal's single
anonymized review process.*
