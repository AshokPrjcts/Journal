# Submission Package — Knowledge-Based Systems (Elsevier)

**Paper:** Knowledge-Based Machine Learning for Data-Driven Decision Intelligence
in Digital Transformation and Entrepreneurship
**Article type:** Short Communication

## Contents of this package

| # | File | Purpose |
|---|------|---------|
| 1 | `01_cover_letter.md` | Cover letter to the Editor-in-Chief |
| 2 | `02_title_page.md` | Title page (authors, affiliations, corresponding author) |
| 3 | `03_manuscript.md` | Main manuscript (anonymized body: no author names) |
| 4 | `04_highlights.md` | Highlights (3–5 bullets, ≤85 chars each) |
| 5 | `05_declarations.md` | Competing interests, funding, CRediT, GenAI, data statement |
| 6 | `figures/Figure_1.svg` | Figure 1 — ROC curves + KG-DI decision landscape |
| 7 | `figures/Figure_2.svg` | Figure 2 — factorial ablation + cost-sensitive thresholding |
| 8 | `tables/Table_1.csv` | Table 1 — predictive performance (editable) |
| 9 | `tables/Table_2.csv` | Table 2 — paired significance tests (editable) |
| 10 | `supplementary/ablation_sweep.csv` | Supplementary data (ablation + sensitivity sweep) |
| 11 | `supplementary/code/` | Reproducible source code (data, models, stats, experiment) |
| 12 | `supplementary/README.md` | How to reproduce every result |

## KBS author-guideline compliance

- [x] Short communication, concise (≤10 double-spaced pages incl. tables/figures)
- [x] Abstract ≤250 words, standalone, no references
- [x] 1–7 keywords, single-concept
- [x] Highlights: 5 bullets, ≤85 characters each
- [x] Numbered sections; equations as editable text and numbered
- [x] Tables as editable text (CSV), cited and numbered, no vertical rules
- [x] Figures as separate files, cited and numbered, vector format
- [x] Numbered reference style [n] with DOIs
- [x] CRediT, competing-interests, funding, data statement, GenAI declaration
- [x] Research data: public repository + one-command reproduction

## IMPORTANT — before you submit

1. Fill author name, affiliation, and corresponding-author email in
   `02_title_page.md` and `05_declarations.md` (CRediT).
2. Convert `03_manuscript.md` to **.docx or LaTeX** — KBS does not accept PDF as
   the editable source file. (Open the .md in Word, or paste into the Elsevier
   LaTeX template.)
3. Verify the author lists of references [11], [20], [22], [24] on the publisher
   pages (journal/volume/DOI are already correct).
4. For a true empirical submission, replace the synthetic dataset with real
   firm data and deposit it (Zenodo/Mendeley), then cite it (pipeline supports
   a drop-in swap; this is disclosed in the manuscript Limitations).
5. Optional: a graphical abstract (KBS supports but does not require one).
