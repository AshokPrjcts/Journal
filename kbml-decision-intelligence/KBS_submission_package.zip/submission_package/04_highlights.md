# Highlights

- KG-DI embeds digital-transformation knowledge as a prior in a boosted learner
- KG-DI gives the highest AUC against four baselines over 24 matched splits
- A factorial ablation shows knowledge and boosting each add significant value
- A cost-sensitive layer cuts expected managerial cost by about 60%
- A compact, zero-dependency implementation makes every result reproducible
